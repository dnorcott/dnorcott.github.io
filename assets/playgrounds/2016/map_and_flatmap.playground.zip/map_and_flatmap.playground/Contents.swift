//: Playground - noun: a place where people can play

import UIKit

// A simple struct
struct Song {
    let title: String
}

// Sample data: the first few tracks from a Rolling Stones album, represented in JSON
let beggarsBanquetData = [
    ["title": "Sympathy for the Devil"],
    ["title": "No Expectations"],
    ["title": "Dear Doctor"]
]

// A function to create a Song based on a dictionary
func dictionaryToSong(dict: [String: String]) -> Song {
    let songTitle = dict["title"] ?? "Unknown"
    return Song(title: songTitle)
}

// Create an array of songs from the sample data
var beggarsBanquet0: [Song] = []
for jsonDict in beggarsBanquetData {
    let song = dictionaryToSong(jsonDict)
    beggarsBanquet0.append(song)
}
// result: [Song, Song, Song]

let beggarsBanquet1 = beggarsBanquetData.map { (jsonDictionary: [String : String]) -> Song in
    return dictionaryToSong(jsonDictionary)
}

let beggarsBanquet2 = beggarsBanquetData.map {
    return dictionaryToSong($0)
}

let beggarsBanquet3 = beggarsBanquetData.map(dictionaryToSong)

let rocksOff = Song(title: "Rocks Off")
beggarsBanquet0.append(rocksOff)
// NO! "Rocks Off" is the first song off 1972's Exile on Main St, not Beggar's Banquet! Who let you modify this array?!

//beggarsBanquet3.append(rocksOff)
// Compile error


// Sample data: the Extended edition of the album with a video at the end
let beggarsBanquetExtData = [
    ["title": "Sympathy for the Devil"],
    ["title": "No Expectations"],
    ["title": "Dear Doctor"],
    ["video": "Video Interview"]
]

// Function to create an optional Song from a dictionary
func dictionaryToOptionalSong(dict: [String: String]) -> Song? {
    guard let songTitle = dict["title"] else {
        return nil
    }
    
    return Song(title: songTitle)
}

let beggarsBanquet4 = beggarsBanquetExtData.map(dictionaryToOptionalSong)
// result: [Song, Song, Song, nil]

let beggarsBanquet5 = beggarsBanquetExtData.flatMap(dictionaryToOptionalSong)
// result: [Song, Song, Song]


func isAboutDoctors(song: Song) -> Bool {
    return song.title.containsString("Doctor")
}

let songsAboutDoctors = beggarsBanquetData.map(dictionaryToSong).filter(isAboutDoctors)
print(songsAboutDoctors)

let lazyBeggarsBanquet = beggarsBanquetData.lazy.map(dictionaryToSong)
print(lazyBeggarsBanquet[2])

let prodigalSon1: Song = Song(title: "Prodigal Son")
//prodigalSon1.map(isAboutDoctors)
// Compile error!

let prodigalSon2: Song? = Song(title: "Prodigal Son")
prodigalSon2.map(isAboutDoctors)
// result: false

