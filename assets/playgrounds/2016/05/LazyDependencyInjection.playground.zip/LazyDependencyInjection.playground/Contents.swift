//
// Getting Lazy with Protocols and Dependency Injection
// http://www.norchops.com/lazy-dependency-injection
// Copyright © David Norcott 2016
//

import UIKit

protocol RecordingDevice {
    func startRecording(favoriteSong: String)
}

class Musician {
    
    lazy var mic:RecordingDevice = Microphone()
    
    let favoriteSong: String
    
    init(favoriteSong: String) {
        self.favoriteSong = favoriteSong
    }
    
    func sing() {
        self.mic.startRecording(self.favoriteSong)
    }
}

class Microphone: RecordingDevice {
    init() {
        print("Accessing database...")
        print("Observing NSNotifications...")
    }
    
    func startRecording(favoriteSong: String) {
        print(favoriteSong)
    }
}

class MockMicrophone: RecordingDevice {
    var recentSong: String?
    
    init() {
        print("Created MockMicrophone")
    }
    
    func startRecording(song: String) {
        self.recentSong = song
    }
}


let mockMic = MockMicrophone()

let prince = Musician(favoriteSong: "Purple Rain")
prince.mic = mockMic
prince.sing()

print(mockMic.recentSong)
//XCTAssertEqual(mockMic.recentSong, "Purple Rain")
